﻿请在本地玩通之后上传exp到服务器的/home/D0g3/Meow/tmp
like this:
scp -P2333 /path/to/your/exp D0g3@222.18.158.244:/home/D0g3/Meow/tmp	(passwd: guest)

运行start.sh即可。

ps: tmp文件夹每3分钟会刷新一次，请尽快完成操作拿到flag以免exp被删
